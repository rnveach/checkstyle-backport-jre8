package com.google.checkstyle.test.chapter5naming.rule521packagenames; //ok
final class InputPackageNameGood {}
