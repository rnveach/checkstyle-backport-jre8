package org.checkstyle.suppressionxpathfilter.constantname;

public class SuppressionXpathRegressionConstantNameLowercase {
    public static final int number = 7; // warn
}
