package org.checkstyle.suppressionxpathfilter.annotationusestyle;

@SuppressWarnings({"something",}) //warn
public class SuppressionXpathRegressionAnnotationUseStyleEight {

}
