package org.checkstyle.suppressionxpathfilter.constantname;

public class SuppressionXpathRegressionConstantNameCamelCase {
    public static final int badConstant = 2; // warn
}
