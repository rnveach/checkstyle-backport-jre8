package org.checkstyle.suppressionxpathfilter.importorder;

import java.io.*;
import org.junit.*; // warn

public class SuppressionXpathRegressionImportOrderThree {
    // code
}
