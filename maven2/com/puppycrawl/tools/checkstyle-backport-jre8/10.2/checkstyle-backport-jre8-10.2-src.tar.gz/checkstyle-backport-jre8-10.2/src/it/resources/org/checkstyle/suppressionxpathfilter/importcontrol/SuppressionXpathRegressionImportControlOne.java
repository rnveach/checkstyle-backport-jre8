package org.checkstyle.suppressionxpathfilter.importcontrol;

import java.util.Scanner; //warn

public class SuppressionXpathRegressionImportControlOne {

}
