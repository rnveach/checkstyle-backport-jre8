package org.checkstyle.suppressionxpathfilter.abstractclassname;

public abstract class SuppressionXpathRegressionAbstractClassNameTop { // warn
}
