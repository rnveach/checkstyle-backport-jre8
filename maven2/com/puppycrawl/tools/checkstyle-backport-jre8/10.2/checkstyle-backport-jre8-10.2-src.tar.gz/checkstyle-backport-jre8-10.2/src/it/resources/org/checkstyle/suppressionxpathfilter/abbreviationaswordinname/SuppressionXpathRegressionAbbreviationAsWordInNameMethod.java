package org.checkstyle.suppressionxpathfilter.abbreviationaswordinname;

public interface SuppressionXpathRegressionAbbreviationAsWordInNameMethod {

    void METHOD(); // warn

}
