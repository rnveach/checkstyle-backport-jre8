package org.checkstyle.suppressionxpathfilter.abbreviationaswordinname;

public class SuppressionXpathRegressionAbbreviationAsWordInNameVariable {

    void method() {
        int VARIABLE; // warn
    }

}
