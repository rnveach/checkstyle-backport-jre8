package org.checkstyle.suppressionxpathfilter.illegaltoken;

public class SuppressionXpathRegressionIllegalToken2 {
  public native void myTest(); // warn
}
