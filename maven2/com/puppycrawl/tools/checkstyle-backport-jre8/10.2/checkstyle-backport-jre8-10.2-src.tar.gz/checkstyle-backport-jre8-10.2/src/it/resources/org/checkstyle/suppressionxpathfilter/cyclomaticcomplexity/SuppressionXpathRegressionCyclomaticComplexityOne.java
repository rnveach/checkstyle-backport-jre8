package org.checkstyle.suppressionxpathfilter.cyclomaticcomplexity;

public class SuppressionXpathRegressionCyclomaticComplexityOne {
    public void test(int a, int b) { //warn
        if (a > b) {

        } else {

        }
    }
}
