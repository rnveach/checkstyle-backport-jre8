package org.checkstyle.suppressionxpathfilter.commentsindentation;

public class SuppressionXpathRegressionCommentsIndentationBlock {
          /* // warn
           * Javadoc comment
           */
    float f;
}
