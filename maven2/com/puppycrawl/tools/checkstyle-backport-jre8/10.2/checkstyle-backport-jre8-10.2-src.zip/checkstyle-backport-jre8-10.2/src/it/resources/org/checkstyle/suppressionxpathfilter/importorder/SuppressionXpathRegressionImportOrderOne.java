package org.checkstyle.suppressionxpathfilter.importorder;

import static java.lang.Math.PI;
import java.util.Set; // warn

public class SuppressionXpathRegressionImportOrderOne {
    // code
}
