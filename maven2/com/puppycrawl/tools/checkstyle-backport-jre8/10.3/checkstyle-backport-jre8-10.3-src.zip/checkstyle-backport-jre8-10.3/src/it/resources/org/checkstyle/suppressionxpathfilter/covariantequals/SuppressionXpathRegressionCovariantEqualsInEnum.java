package org.checkstyle.suppressionxpathfilter.covariantequals;

public enum SuppressionXpathRegressionCovariantEqualsInEnum {

    EQUALS;

    public boolean equals(SuppressionXpathRegressionCovariantEqualsInEnum i) { // warn
        return false;
    }

}
