package org.checkstyle.suppressionxpathfilter.avoidstaticimport;

import static java.io.File.createTempFile; // warn

public class SuppressionXpathRegressionAvoidStaticImport2 {
}
