package org.checkstyle.suppressionxpathfilter.arraytypestyle;

public class SuppressionXpathRegressionArrayTypeStyleMethodDef {
    byte getData()[] { // warn
        return null;
    }
}
