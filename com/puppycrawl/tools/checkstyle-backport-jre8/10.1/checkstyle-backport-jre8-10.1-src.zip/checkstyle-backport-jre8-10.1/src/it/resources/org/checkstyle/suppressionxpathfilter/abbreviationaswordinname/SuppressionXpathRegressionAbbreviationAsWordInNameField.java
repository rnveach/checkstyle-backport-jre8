package org.checkstyle.suppressionxpathfilter.abbreviationaswordinname;

public class SuppressionXpathRegressionAbbreviationAsWordInNameField {

    int FIELD; // warn

}
