package org.checkstyle.suppressionxpathfilter.annotationusestyle;

@SuppressWarnings({}) //warn
public class SuppressionXpathRegressionAnnotationUseStyleFour {

}
