package org.checkstyle.suppressionxpathfilter.annotationusestyle;

@SuppressWarnings({"foo", "bar"}) //warn
public class SuppressionXpathRegressionAnnotationUseStyleSix {

}
