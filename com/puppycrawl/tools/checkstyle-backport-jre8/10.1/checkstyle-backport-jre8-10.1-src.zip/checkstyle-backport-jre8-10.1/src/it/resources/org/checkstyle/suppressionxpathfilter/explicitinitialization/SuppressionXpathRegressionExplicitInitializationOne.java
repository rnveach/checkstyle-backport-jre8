package org.checkstyle.suppressionxpathfilter.explicitinitialization;

public class SuppressionXpathRegressionExplicitInitializationOne {
    private int a = 0; //warn
}
