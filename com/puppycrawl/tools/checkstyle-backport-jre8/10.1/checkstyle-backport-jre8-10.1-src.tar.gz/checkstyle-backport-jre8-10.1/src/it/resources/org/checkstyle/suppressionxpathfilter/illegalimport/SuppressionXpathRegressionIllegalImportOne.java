package org.checkstyle.suppressionxpathfilter.illegalimport;

import java.util.List; // warn

public class SuppressionXpathRegressionIllegalImportOne {
}
